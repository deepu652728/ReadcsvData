from pyspark.sql.functions import col, count
from pyspark import SparkContext, SparkConf
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *

if __name__ == "__main__":
    print("Real-Time Data Pipeline Started ...")

    spark = SparkSession \
        .builder \
        .appName("Real-Time Data Pipeline Demo") \
        .master("local[*]") \
        .config("spark.jars", "file:///G://jars//spark-sql-kafka-0-10_2.11-2.4.0.jar,"
                              "file:///G://jars//kafka-clients-1.1.0.jar,"
                              "file:///G://jars//spark-excel_2.11-0.8.2.jar,"
                              "file:///G://jars//mariadb-java-client-2.7.2.jar,"
                ) \
        .config("spark.executor.extraClassPath", "file:///G://jars//spark-sql-kafka-0-10_2.11-2.4.0.jar:"
                                                 "file:///G://jars//kafka-clients-1.1.0.jar:"

                ) \
        .config("spark.executor.extraLibrary", "file:///G://jars//spark-sql-kafka-0-10_2.11-2.4.0.jar:"
                                               "file:///G://jars//kafka-clients-1.1.0.jar:"

                ) \
        .config("spark.driver.extraClassPath", "file:///G://jars//spark-sql-kafka-0-10_2.11-2.4.0.jar:"
                                               "file:///G://jars//kafka-clients-1.1.0.jar:"

                ) \
        .getOrCreate()
print("out of libraries")

# schema = StructType(
#     [
#         StructField("report_time", DateType()),
#         StructField("client_device", StringType()),
#         StructField("equip_id", StringType())
#
#     ]
# )
df = spark.read.csv("C:/Users/admin/Desktop/testdata.csv", header=True, inferSchema=True)
# df = spark.read.format("com.crealytics.spark.excel").option("useHeader", "true"). \
#     schema(schema).\
#     option("inferSchema", "true").option("location", "C:/Users/admin/Desktop/data.xlsx"). \
#     option("addColorColumns", "false"). \
#     option("treatEmptyValuesAsNulls", "false"). \
#     option("dateFormat", "yyyy-MM-dd HH:mm:ss"). \
#     load("C:/Users/admin/Desktop/data.xlsx")
df.printSchema()
print(df.show())

df1 = df.agg({'report_time': 'max'}).collect()[0]
print(df1)
df2 = (df1["max(report_time)"])
print(df2)
# df2=df1.selectExpr("max(report_time as report_time")
# print(df1.show())
df.write.format('jdbc').options(
    url='jdbc:mariadb://localhost:3306/testdb',
    driver='org.mariadb.jdbc.Driver',
    dbtable='max_value',
    user='root',
    password='root').mode('append').save()
